The Last Order

this set spent me almost a whole week.after finished it,i feel so tired.
but i'll still keep working soon! as i say:Run forever :D
and thanks the guys in Chinaui/CCF/5D/ThemeX/Neowin forum
your support driving me keep going!
welcome to my house www.rokey.net to get more :)

Highly recommend use the 48X48 or 128X128 size.

Windows user:
use the Microangelo or Axialis IconWorkshop browse(or pickup)the .ico or .icl files;
use the IconPackager run the .ip file to repleace the system icon.

Mac user:
use "Pixadex"(http://www.iconfactory.com/px_home.asp) convert the .ico files(WindowsOS icon file format) to Mac icon format.

Special Thanks:
Bluesky(help me solve a key problem)
CCF Forum guys(give me some good suggestions)
Cuckoo(help me named the iconset)

Notification:
This works is only for personal use.
It is fobidden to use it for business purpose without authorization.

my website: www.rokey.net
mail: webmaster@rokey.net

04.07.2004